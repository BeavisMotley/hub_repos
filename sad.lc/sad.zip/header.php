<header class="top_header">
	    <div class="container">
	        <div class='col-md-12'>
	            <div class='row' id="h_row"><p id="mbdoy">Муниципальное бюджетное дошкольное
                    образовательное учреждение "Детский сад комбинированного вида №10"Дружные ребята" муниципального образования городской округ Симферополь Республики Крым</p>
                   <p id='logo_img'><img src="img/Logo.png" class="img_responsive logo"/></p>             
                   <nav class="main_mnu_small" style='text-align:center;'>                    
                    <ul><button class="main_menu_button hidden-md hidden-lg ">&nbsp;&nbsp;&nbsp;<i class='fa fa-bars'></i><p id='m_list'>&nbsp;Меню</p></button>
                        <div class="main_menu_list hidden-md hidden-lg ">
                            <div  id='sm_menu'>
                                <ul>
                                    <li><button class="main_menu_button hidden-md hidden-lg ">Кто мы</button>
                                      <div class="main_menu_list hidden-md hidden-lg ">
                                       <ul>
                                       <li><a href="index.php">Главная</a></li>
                                        
                                            <li><a href="collective.php">Коллектив единомышленников</a></li>
                                            <li><a href="npd.php">Нормативно-правовые документы</a></li>
                                            <li><a href="v_sotrudnichestve.php">В сотрудничестве с семьей</a></li>
                                        </ul>
                                        </div>
                                        </li>
                                    <li><button class="main_menu_button hidden-md hidden-lg ">Сведения</button>
                                       <div class="main_menu_list hidden-md hidden-lg ">
                                        <ul>
                                            <li><a href="main_info.php">Основные сведения</a></li>
                                            <li><a href="docs.php">Документы</a></li>
                                            <li><a href="educ.php">Образование</a></li>
                                            <li><a href="educ_standerts.php">Образовательные стандарты</a></li>
                                            <li><a href="p_sostav.php">Руководство. Педагогический состав</a></li>
                                            <li><a href="p_educ_s.php">Платные образовательные услуги</a></li>
                                            <li><a href="f_hoz.php">Финансово-хозяйственная деятельность</a></li>
                                        </ul>
                                        </div>
                                    </li>
                                    <li><button class="main_menu_button hidden-md hidden-lg ">Комфорт</button>
                                      <div class="main_menu_list hidden-md hidden-lg ">
                                        <ul>
                                            <li><a href="g_pomesheniya.php">Групповые помещения</a></li>
                                            <li><a href="http://sads.lc/index.php?id=sadslcnews&lang=ru">Кабинеты специалистов</a></li>
                                        </ul>
                                        </div>
                                    </li>   
                                    <li><button class="main_menu_button hidden-md hidden-lg ">Образовательный маршрут</button>
                                      <div class="main_menu_list hidden-md hidden-lg ">
                                        <ul>
                                            <li><button class="main_menu_button hidden-md hidden-lg "><p style="font-size:0.7em;border-top: 1px solid #E5C06E;">Старший воспитатель</p></button>
                                      <div class="main_menu_list hidden-md hidden-lg ">
                                                <ul>
                                                   <li><a href="st_vosp.php">Личная страничка</a></li>
                                                    <li><a href="m_att_period.php">Межаттестационный период</a></li>
                                                    <li><a href="for_parents.php">Для вас, родители</a></li>
                                                    <li><a href="p_soviet.php">Педсовет</a></li>
                                                    </li>                                  
                                        </ul>
                                            </div>
                                    <li ><a href="vospitateli.php">Воспитатель - добрый учитель</a></li>
                                    <li><a href="vmeste_s_logopedom.php">Вместе с логопедом</a></li>
                                    <li><a href="#">В мире музыки</a></li>
                                    <li><a href="golub_o_i.php">Физкультура и спорт</a></li>
                                    <li><a href="#">Педагог - психолог советует</a></li>
                                </ul>
                                    </div>
                                </li>
                            <li><button class="main_menu_button hidden-md hidden-lg ">Культура здоровья</button>
                                      <div class="main_menu_list hidden-md hidden-lg ">
                                <ul>
                                    <li><a href="#">Рациональное питание</a></li>                                
                                    <li><a href="#">Валеология - наука о здоровье</a>
                                    <li><a href="#">Безопасность жизнедеятельности</a></li></li>  
                            </ul>
                        </div>
                        </li>
                    <li><a href="contacts.php" style="font-size:1.9em; padding:-40px; text-transform:none;">Контакты</a></li>
                    </ul>  
            </div>
        </div>
        </ul>
    </nav>
                    <nav class="main_mnu_b">
                        
                       <div class="hidden-xs hidden-sm">
                      <div  id='menu'>
                       <ul>
                         <li><a href="index.php">Кто мы</a>
                            <ul>
                                <li><a href="collective.php">Коллектив единомышленников</a></li>
                                <li><a href="#">Нормативно-правовые документы</a></li>
                                <li><a href="v_sotrudnichestve.php">В сотрудничестве с семьей</a></li>
                                                            </ul>
                        </li>
                        <li><a href="main_info.php">Сведения</a>
                            <ul>
                                <li><a href="main_info.php">Основные сведения</a></li>
                                <li><a href="docs.php">Документы</a></li>
                                <li><a href="educ.php">Образование</a></li>
                                <li><a href="educ_standerts.php">Образовательные стандарты</a></li>
                                <li><a href="p_sostav.php">Руководство. Педагогический состав</a></li>
                                 <li><a href="p_educ_s.php">Платные образовательные услуги</a></li>
                                <li><a href="f_hoz.php">Финансово-хозяйственная деятельность</a></li>
                           </ul>
                           </li>
                         <li><a href="#">Комфорт</a>
                            <ul>
                                <li><a href="g_pomesheniya.php">Групповые помещения</a></li>
                                <li><a href="#">Кабинеты специалистов</a></li>
                           </ul>
                           </li>   
                        <li><a href="#">Образовательный маршрут</a>
                           <ul>
                                <li><a href="st_vosp.php">Старший воспитатель</a>
                                    <ul>
                                      <li><a href="m_att_period.php">Межаттестационный период</a></li>
                                      <li><a href="for_parents.php">Для вас, родители</a></li>
                                       <li><a href="p_soviet.php">Педсовет</a></li>
                                      </li>                                  
                                    </ul>
                                <li ><a href="vospitateli.php">Воспитатель - добрый учитель</a></li>
                                <li><a href="vmeste_s_logopedom.php">Вместе с логопедом</a></li>
                                <li><a href="#">В мире музыки</a></li>
                                <li><a href="golub_o_i.php">Физкультура и спорт</a></li>
                                <li><a href="#">Педагог - психолог советует</a></li>
                            </ul>
                           </li>                          
                        
                            <li><a href="#">Культура здоровья</a>
                            <ul>
                                <li><a href="#">Рациональное питание</a></li>                                
                                <li><a href="#">Валеология - наука о здоровье</a>
                                <li><a href="#">Безопасность жизнедеятельности</a></li></li>  
                           </ul>
                           </li>
                        <li><a href="contacts.php">Контакты</a></li>
                       
                        </ul>
                        
                       
                        
                        </ul>
                     </div> 
	                </div>
                 </nav>
	        </div>
	    </div>
	</header>