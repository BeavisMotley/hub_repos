<header class="top_header">
	    <div class="container">
	        <div class='col-md-12'>
	            <div class='row' id="h_row"><p id="mbdoy">Муниципальное бюджетное дошкольное
                    образовательное учреждение "Детский сад комбинированного вида №10"Дружные ребята" муниципального образования городской округ Симферополь Республики Крым</p>
                   <p id='logo_img'><img src="../img/Logo.png" class="img_responsive logo"/></p>             
                    <nav class="main_mnu">                    
                    <ul><button class="main_menu_button hidden-md hidden-lg "><i class='fa fa-bars'></i><p id='m_list'>&nbsp;Меню</p></button>
                        <div class="main_menu_list hidden-md hidden-lg ">
                        <li><a href="#">Главная</a></li>
                        <li><a href="#">Страна детства</a></li>
                        <li><a href="#">Страница педагога</a></li>
                        <li><a href="#">Вместе с семьей</a></li>
                        <li><a href="#">Сведения</a></li>
                        <li><a href="#">Контакты</a></li>
                        </div>
                    </ul>
                    </nav>
                    <nav class="main_mnu_b">
                        
                       <div class="hidden-xs hidden-sm">
                      <div  id='menu'>
                       <ul>
                         <li><a href="../index.php">Кто мы</a>
                            <ul>
                                <li><a href="../collective.php">Коллектив единомышленников</a></li>
                                <li><a href="#">Нормативно-правовые документы</a></li>
                                <li><a href="../v_sotrudnichestve.php">В сотрудничестве с семьей</a></li>
                                                            </ul>
                        </li>
                        <li><a href="../main_info.php">Сведения</a>
                            <ul>
                                <li><a href="../docs.php">Документы</a></li>
                                <li><a href="../educ.php">Образование</a></li>
                                <li><a href="../educ_standerts.php">Образовательные стандарты</a></li>
                                <li><a href="../p_sostav.php">Руководство. Педагогический состав</a></li>
                                 <li><a href="../p_educ_s.php">Платные образовательные услуги</a></li>
                                <li><a href="../f_hoz.php">Финансово-хозяйственная деятельность</a></li>
                           </ul>
                           </li>
                         <li><a href="#">Комфорт</a>
                            <ul>
                                <li><a href="../g_pomesheniya.php">Групповые помещения</a></li>
                                <li><a href="#">Кабинеты специалистов</a></li>
                           </ul>
                           </li>   
                        <li><a href="#">Образовательный маршрут</a>
                           <ul>
                                <li><a href="../st_vosp.php">Старший воспитатель</a>
                                    <ul>
                                      <li><a href="../m_att_period.php">Межаттестационный период</a></li>
                                      <li><a href="../for_parents.php">Для вас, родители</a></li>
                                       <li><a href="../p_soviet.php">Педсовет</a></li>
                                      </li>                                  
                                    </ul>
                                <li ><a href="../vospitateli.php">Воспитатель - добрый учитель</a></li>
                                <li><a href="../vmeste_s_logopedom.php">Вместе с логопедом</a></li>
                                <li><a href="#">В мире музыки</a></li>
                                <li><a href="../golub_o_i.php">Физкультура и спорт</a></li>
                                <li><a href="#">Педагог - психолог советует</a></li>
                            </ul>
                           </li>                          
                        
                            <li><a href="#">Культура здоровья</a>
                            <ul>
                                <li><a href="#">Рациональное питание</a></li>                                
                                <li><a href="#">Валеология - наука о здоровье</a>
                                <li><a href="#">Безопасность жизнедеятельности</a></li></li>  
                           </ul>
                           </li>
                        <li><a href="../contacts.php">Контакты</a></li>
                       
                        </ul>
                        
                       
                        
                        </ul>
                     </div> 
	                </div>
                 </nav>
	        </div>
	    </div>
	</header>