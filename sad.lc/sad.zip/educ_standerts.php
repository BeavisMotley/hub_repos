<?php
$title='Образование|МБДОУ№10"Дружные ребята"';
require('head.php');
?>
</head>
<body>
    <?php
    ini_set('error_reporting', E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);

    require('header.php');
    ?>
    <section class="main_content">
        <div class="container" >
            <div class="row">
                <div class="col-md-12 ">
                    <div class="col-md-3 ">
                        <?php
                        require('news.php');
                        ?>	
                    </div>
                    <div class="col-md-9">
                        <div class="content-text">
                            <div class="blog_item">
                            <div style="font-weight:bold; text-align:center;"><a class="fancybox" data-fancybox-group="group" href="docs/1155.bmp"><img src="docs/1155.bmp" class="img-rounded" alt="alt"  width='90%' /></a><br><br>
                                <button><a href="docs/%D0%9F%D1%80%D0%B8%D0%BA%D0%B0%D0%B7%20%E2%84%96%201155%20%D0%BE%D1%8217.10.2013%20%D0%B3..pdf">Загрузить полную версию документа</a></button></div><br>
                               </a><br><br>
                                <a href="http://xn--80abucjiibhv9a.xn--p1ai/%D0%B4%D0%BE%D0%BA%D1%83%D0%BC%D0%B5%D0%BD%D1%82%D1%8B/6261/%D1%84%D0%B0%D0%B9%D0%BB/5230/%D0%9F%D1%80%D0%B8%D0%BA%D0%B0%D0%B7%20%E2%84%96%201155%20%D0%BE%D1%8217.10.2013%20%D0%B3..pdf">&nbsp;--> Ссылка на оригинал документа <--</a>
                             
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <?php
    require('footer.php');
    ?>