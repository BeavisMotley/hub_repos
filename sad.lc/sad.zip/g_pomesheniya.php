<?php
     $title='Групповые помещения|МБДОУ№10"Дружные ребята"';
    require('head.php');
?>
</head>
<body>
   <?php
    ini_set('error_reporting', E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
            
            require('header.php');
?>
       <section class="main_content">
        <div class="container" >
            <div class="row">
                <div class="col-md-12 ">
                 <div class="col-md-3 ">
				<?php
         require('news.php');
?>	                
                   </div>
                    <div class="col-md-9">
					<div class="content-text">
						<div class="blog_item">
                             <p><H2 style="text-align:center">«НАШ УЮТНЫЙ, ТЁПЛЫЙ ДОМ, ДОМ В КОТОРОМ МЫ ЖИВЁМ!»<br>(экскусия по детскому саду)</H2>
  В МБДОУ №10 «Дружные ребята» 8 возрастных групп: 2 группы раннего возраста, 2 спецгруппы (логопедические), 4 группы дошкольного возраста.<br>
Дошкольное учреждение рассчитано на 144 места.              
<h4 style="text-align:center;color:green;">Познакомьтесь!</h4>
 
<h3 id="zaychata">Группа №02 – «Зайчата»<img src="img/z_logo.png" class="g_logo"></h3>
 <img src="img/zaychata/zaychata_02.jpg" class="img_responsive logo img-rounded"id='events'/>
Прием детей в группу раннего развития ведется с 2 лет.  Группа «Зайчата» – уютный, милый  дом для любознательных мальчиков и  девочек. Их любят, как своих собственных, заботятся о малышах, развивают.  Группа наполнена  современным игровым материалом, с помощью которого  дети узнают окружающий мир. Здесь  всегда звучит веселый, радостный смех .Дети  любят сказки, с радостью знакомятся с разными  играми.<br><br><br><br><br><br><br><br><br><br><br><br><br><br>     
                         <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zaychata/zaychata_01.jpg"><img src="img/zaychata/zaychata_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zaychata/zaychata_03.jpg"><img src="img/zaychata/zaychata_03.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zaychata/zaychata_04.jpg"><img src="img/zaychata/zaychata_04.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zaychata/zaychata_05.jpg"><img src="img/zaychata/zaychata_05.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zaychata_06.jpg"><img src="img/zaychata/zaychata_06.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zaychata/zaychata_07.jpg"><img src="img/zaychata/zaychata_07.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>
    <h3 id="luchiki">Группа №03 – «Лучики» <img src="img/l_logo.png" class="g_logo"></h3>Название  группы не случайное, потому что каждый ребенок, который приходит сюда – это СОЛНЕЧНЫЙ ЛУЧИК! Искренние, веселые, любознательные, добрые – это портрет детей группы «Лучики». В группе созданы благоприятные условия, способствующие укреплению и сохранению здоровья детей, развитию интеллектуальных, творческих способностей каждого ребенка. Дети заботятся о комнатных растениях, выращиваютцветы, лук в группе- и для того, чтобы трудиться и для здоровья! Ведь это так важно - воспитывать у детей доброе отношение к окружающему миру , формировать позитивные и нравственные качества!  
                              <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/luch_01.jpg"><img src="img/luch_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/luch_02.jpg"><img src="img/luch_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/luch_03.jpg"><img src="img/luch_03.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>
    <h3 id="vesnushki">Группа №04 – «Веснушки»<img src="img/v_logo.png" class="g_logo"></h3>
    <h5 style="font-style:italic;font-weight:bold;"><span style="color: #9F7A7A;">
Как в гавань теплую всегда<br>
Идут с надеждой все сюда<br>
Что здесь научат говорить,<br>
Но надо двери отворить,<br>
И главным стать родителем:<br>
Участником – не зрителем,<br>
И чтоб ребенку на пути<br>
Не одному весь груз нести.<br>
Потом он сможет, а пока<br>
        Ему нужна твоя рука!<br></span>
</h5>
   Светлое, просторное помещение. В группе созданы все условия для развития познавательной, двигательной активности детей. Творческие, талантливые люди помогают раскрыть индивидуальные способности детей исходя из желаний, интересов каждого ребенка.
                              <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_01.jpg"><img src="img/vesn_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_02.jpg"><img src="img/vesn_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_03.jpg"><img src="img/vesn_03.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_04.jpg"><img src="img/vesn_04.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_05.jpg"><img src="img/vesn_05.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_06.jpg"><img src="img/vesn_06.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_07.jpg"><img src="img/vesn_07.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_08.jpg"><img src="img/vesn_08.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/vesn_09.jpg"><img src="img/vesn_09.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>                         
<h3 id="raduga">Группа №05 – «Радуга»<img src="img/r_logo.png" class="g_logo"></h3>
<h5 style="font-style:italic;font-weight:bold;">
 <span style="color:#B1FE36;">Весело в группе нам жить –</span><br> 
<span style="color:#37DBF6;">Любим учиться, играть и дружить.</span><br>
<span style="color:#1878F9;">Будем, как пчелки в улье трудиться,</span><br>
    <span style="color:#676DE9;">Все это нам пригодиться!</span></h5>
          <span style="color:#B562BA;"><h5>Наш девиз: «Мы как радуги цвета неразлучны никогда!» .</h5></span>
            Для активной жизнедеятельности детей в группе создана современная  предметно-развивающая среда, ориентированная на формирование высокодуховной личности ребенка, развитие его творческого потенциала.
В группе много игрового материала, удобная мебель, просторная спальня, современная предметно-развивающая среда. ПРИХОДИТЕ К НАМ!
                                 <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_01.jpg"><img src="img/rad_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_02.jpg"><img src="img/rad_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_03.jpg"><img src="img/rad_03.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_04.jpg"><img src="img/rad_04.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_05.jpg"><img src="img/rad_05.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_06.jpg"><img src="img/rad_06.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_07.jpg"><img src="img/rad_07.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_08.jpg"><img src="img/rad_08.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_09.jpg"><img src="img/rad_09.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/rad_10.jpg"><img src="img/rad_10.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>
<h3 id="pochemuchki">Группа №06 – «Почемучки»<img src="img/p_logo.png" class="g_logo"></h3>
Основная специализация группы- речевое развитие детей через все виды игровой деятельности. В группе благоприятные условия для полноценного проживания детьми дошкольного детства, формирование основ базовой культуры личности, всестороннего развития физических и психических качеств в соответствии с возрастными и индивидуальными особенностями подготовки ребенка к жизни в современном обществе.    
                     <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/poch_01.jpg"><img src="img/poch_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/poch_02.jpg"><img src="img/poch_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/poch_04.jpg"><img src="img/poch_04.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>                            
<h3 id="ulibashki">Группа №07 – «Улыбашки»<img src="img/u_logo.png" class="g_logo"></h3>
В этой группе встречают с улыбкой, здесь в обиду не дадут, слезы вытрут, приласкают, книжку добрую прочтут... 
Совершенствование педпроцесса на основе интеграции учебно-воспитательных заданий, поисковой деятельности, способствует формированию базовых качеств личности для дальнейшего обучения в школе. 
                        <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/ulib_01.jpg"><img src="img/ulib_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/ulib_02.jpg"><img src="img/ulib_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/ulib_03.jpg"><img src="img/ulib_03.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/ulib_04.jpg"><img src="img/ulib_04.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>
<h3 id="kapelki">Группа №08 – «Капельки»<img src="img/k_logo.png" class="g_logo"></h3>
<h5 style="font-style:italic;font-weight:bold;">
    <span style="color:#2FB9F2;">«Мы капельки – малышки,</span><br>
    <span style="color:#0E73BF;">Девчонки и мальчишки.</span><br>
    <span style="color:#4C42EA;">Любим мы играть, петь и рисовать».</span></h5>
Каждый из нас – всего лишь капля, а вместе мы ручей, пока маленький, но очень добрый! Мы хотим, чтобы нашим детям- капелькам было тепло и солнечно! 
Если Вашему солнышку одиноко или Вам хочется поделиться своим теплом – приходите к нам, мы будем рады подружиться с Вами!
                            <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_01.jpg"><img src="img/kap_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_02.jpg"><img src="img/kap_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_03.jpg"><img src="img/kap_03.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_04.jpg"><img src="img/kap_04.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_05.jpg"><img src="img/kap_05.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_06.jpg"><img src="img/kap_06.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_07.jpg"><img src="img/kap_07.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_08.jpg"><img src="img/kap_08.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_09.jpg"><img src="img/kap_09.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/kap_10.jpg"><img src="img/kap_10.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
						</div>
					</div>                                        
<h3 id="zvonochki">Группа №09 – «Звоночки»<img src="img/zv_logo.png" class="g_logo"></h3>             <h5 style="font-style:italic;font-weight:bold;">
<span style="color:#FFD700;">Мы веселые «Звоночки»</span><br>
<span style="color:#FFD700;">Нам весь день звенеть не лень</span><br>
<span style="color: #FFD700;">Мы звеним, не умолкая</span><br>
<span style="color: #FFD700;">Динь – дилень, динь – дилень!</span></h5>
 <img src="img/zvon/zvon_03.jpg" class="img_responsive logo img-rounded "id='events'/>
  В группе тепло и уютно. Система закаливающих, оздоровительных мероприятий и физическое развитие укрепляют здоровье малышей, развивают активность, любознательность. Материальная среда (физическая обстановка, предметно-пространственный мир), которая окружает ребенка оказывает влияние на его развитие и воспитание.<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>                        
                          <div class="sider_container">
                         <div class="owl-controls">
						<div class='owl-nav'><div class="next_btn"><i class="fa fa-angle-right"></i></div>
						<div class="prev_btn"><i class="fa fa-angle-left"></i></div>
                             </div>
                             </div>
						<div class="carousel">
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_01.jpg"><img src="img/zvon/zvon_01.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_02.jpg"><img src="img/zvon/zvon_02.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_04.jpg"><img src="img/zvon/zvon_04.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_05.jpg"><img src="img/zvon/zvon_05.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_06.jpg"><img src="img/zvon/zvon_06.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_07.jpg"><img src="img/zvon/zvon_07.jpg" class="img-rounded" alt="alt"  width='100%'/></a></div>
							<div class="slide_item"><a class="fancybox" data-fancybox-group="group" href="img/zvon/zvon_08.jpg"><img src="img/zvon/zvon_08.jpg" class="img-rounded" alt="alt"  width='100%' /></a></div>
														
						</div>
					</div>                           
                                                                                                            </p>
                         </div>   
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
    </section>
    <?php
         require('footer.php');
?>